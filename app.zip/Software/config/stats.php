<?php

return [
    'types' => [
        'browser', 'campaign', 'city', 'continent', 'country', 'device', 'event', 'landing_page', 'language', 'os', 'page', 'pageviews', 'pageviews_hours', 'referrer', 'resolution', 'visitors', 'visitors_hours'
    ]
];