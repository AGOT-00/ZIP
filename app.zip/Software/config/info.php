<?php

return [

    'software' => [
        'name'      => 'phpAnalytics',
        'author'    => 'Lunatio',
        'url'       => 'https://lunatio.com',
        'version'   => '3.6.0'
    ]

];
