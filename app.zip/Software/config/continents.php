<?php

return [
    'AS' => 'Asia',
    'AN' => 'Antarctica',
    'AF' => 'Africa',
    'SA' => 'South America',
    'EU' => 'Europe',
    'OC' => 'Oceania',
    'NA' => 'North America'
];
