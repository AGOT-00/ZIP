Update documentation is available at:
https://lunatio.com/phpanalytics/documentation#update